using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleFun : MonoBehaviour
{
    private Vector2 cursorPos;

    struct Particle
    {
        public Vector3 position;
        public Vector3 velocity;
        public float life;
    }

    const int SIZE_PARTCICLE = 7 * sizeof(float);

    public int particleCount = 100000;
    public Material material;
    public ComputeShader shader;
    [Range(1,10)]
    public int pointSize = 2;

    int kernelID;
    ComputeBuffer particleBuffer;

    int groupSizeX;

    // Start is called before the first frame update
    void Start()
    {
        Init();
    }

    void Init()
    {
        Particle[] particleArray = new Particle[particleCount];

        for (int i = 0; i < particleCount; i++)
        {
            Vector3 v = new Vector3();
            v.x = Random.value * 2 - 1.0f;
            v.y = Random.value * 2 - 1.0f;
            v.z = Random.value * 2 - 1.0f;
            v.Normalize();

            v *= Random.value * 0.5f;

            particleArray[i].position.x = v.x;
            particleArray[i].position.y = v.y;
            particleArray[i].position.z = v.z + 3;

            particleArray[i].velocity.x = 0;
            particleArray[i].velocity.y = 0;
            particleArray[i].velocity.z = 0;

            particleArray[i].life = Random.value * 5.0f + 1.0f;
        }

        // Create compuet Buffer
        particleBuffer = new ComputeBuffer(particleCount, SIZE_PARTCICLE);

        particleBuffer.SetData(particleArray);

        //Find the id of the kernel
        kernelID = shader.FindKernel("CSParticle");

        uint threadsX;
        shader.GetKernelThreadGroupSizes(kernelID, out threadsX, out _, out _);

        //Find the number of blocks/group of threads
        groupSizeX = Mathf.CeilToInt((float)particleCount / (float)threadsX);

        //Bind the compute buffer to the shader and the compute buffer
        shader.SetBuffer(kernelID, "particleBuffer", particleBuffer);

        //To be explained next class when we introduced the compute shader
        //and the shader
        material.SetBuffer("particleBuffer", particleBuffer);
        material.SetInt("_PointSize", pointSize);
    }

    void OnRenderObject()
    {
        material.SetPass(0);

        //Topology: Points, Quads, Lines, Strips
        //Second parameter is the number of vertices in a single instance. Since I am using point as a particle
        //I set this to 1
        //Number of particles
        Graphics.DrawProceduralNow(MeshTopology.Points, 1, particleCount);
    }

    void OnDestroy()
    {
        if (particleBuffer != null) particleBuffer.Release();
    }

    // Update is called once per frame
    void Update()
    {

        float[] mousePosition2D = { cursorPos.x, cursorPos.y };

        // Send datas to the compute shader
        shader.SetFloat("deltaTime", Time.deltaTime);
        shader.SetFloats("mousePosition", mousePosition2D);

        // Update the Particles
        shader.Dispatch(kernelID, groupSizeX, 1, 1);
    }

    void OnGUI()
    {
        Vector3 p = new Vector3();
        Camera c = Camera.main;
        Event e = Event.current;
        Vector2 mousePos = new Vector2();

        // Get the mouse position from Event.
        // Note that the y position from Event is inverted.
        mousePos.x = e.mousePosition.x;
        mousePos.y = c.pixelHeight - e.mousePosition.y;

        p = c.ScreenToWorldPoint(new Vector3(mousePos.x, mousePos.y, c.nearClipPlane + 14));// z = 3.

        cursorPos.x = p.x;
        cursorPos.y = p.y;

    }


}
